# Kodi addon to watch JW.org videos on Kodi

Self explanatory, right?
