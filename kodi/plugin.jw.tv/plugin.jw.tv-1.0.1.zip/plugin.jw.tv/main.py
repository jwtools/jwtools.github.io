# -*- coding: utf-8 -*-

from resources.lib import plugin
import xbmcaddon
import logging

# Keep this file to a minimum, as Kodi
# doesn't keep a compiled copy of this
ADDON = xbmcaddon.Addon()

plugin.run()
